package com.example.creepgallery

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.example.creepgallery.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity(), BookClickListener {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Muestra un Snackbar al iniciar la actividad
        val snackbar = Snackbar.make(
            window.decorView.rootView,
            "¡Bienvenido a la galería de terror!",
            Snackbar.LENGTH_LONG
        )
        snackbar.show()

        populateBooks()

        val mainActivity = this
        binding.recyclerView.apply {
            layoutManager = GridLayoutManager(applicationContext, 3)
            adapter = CardAdapter(bookList, mainActivity)
        }

        setupBottomNavigationBar()
    }

    override fun onClick(book: Book) {
        val intent = Intent(applicationContext, DetailActivity::class.java)
        intent.putExtra(BOOK_ID_EXTRA, book.id)
        startActivity(intent)
    }

    private fun populateBooks() {
        val book1 = Book(
            R.drawable.img1,
            "Azul L.",
            "Observado",
            "Observado es una obra que evoca el sentir un observador ajeno a nosotros mientras dormimos. No se sabe exactamente porqué o desde cuando se recuerda esta sensación. Lo que si se sabe con certeza es que hay demasiada gente que ha sentido lo mismo."
        )
        bookList.add(book1)

        val book2 = Book(
            R.drawable.img2,
            "Azul L.",
            "Vista seca",
            "Vista seca es una emotiva obra que denota una desesperanza en aquellos ojos que vieron todo caer, incluso las falsas ilusiones."
        )
        bookList.add(book2)

        val book3 = Book(
            R.drawable.img6,
            "Azul L.",
            "Kevin",
            "La autora originalmente decidió nombra a esta criatura con un nombre común. Esto, según sus palabras, porque no siempre hay que temer algo cuyo nombre es extraño e impronunciable."
        )
        bookList.add(book3)

        val book4 = Book(
            R.drawable.img10,
            "Renata S.",
            "Señora Laura",
            "Señora Laura es una obra que retrata la figura cadavérica de un humanoida cuya cordura y estabilidad física se han deteriorado a tal punto que ni si quiera él o ella misma se reconocen y solo se dejan llevar por sus bajos instintos, pareciendo más a un mounstro que a un humano."
        )
        bookList.add(book4)

        val book5 = Book(
            R.drawable.imgg8,
            "Renata S.",
            "Obstrucción",
            "Obstrucción es la representación literal de aquello que atormenta nuestro decir. Todas las palabras que no puedieron pasar debido a un gran nudo que a estado obstruyendo nuestro conducto se han quedado ahí esperando a que algún día puedan fluir."
        )
        bookList.add(book5)

        val book6 = Book(
            R.drawable.img9,
            "Renata S.",
            "Oficina liminal",
            "Esta obra representa la visión oscura de las personas que nos podemos encontrar en sitios tan comúnes como una oficina de trabajo."
        )
        bookList.add(book6)

        val book7 = Book(
            R.drawable.img3,
            "Andy",
            "Roberto y Jaime",
            "Una obra que representa una amistad contrastante pero duradera, que sin importar como el mundo exterior los vea, ellos dos saben que su relación es honesta y verdadera."
        )
        bookList.add(book7)

        val book8 = Book(
            R.drawable.img4,
            "Andy",
            "Presión autómata",
            "Una obra que retrauna una visión acerca de que ni siquiera los autómatas sin alma pueden escapar de las presiones pequeñas y mundanas impuestas por el ser humano."
        )
        bookList.add(book8)

        val book9 = Book(
            R.drawable.img7,
            "Andy",
            "Los que no sufren",
            "Esta obra trata de aquellos que no pueden sentir ni tristeza, ni felicidad, ni dolor ni nada más. Su suplicio ha llegado a us límite hace mucho timepo y ahora solo se dedican a no sufrir."
        )
        bookList.add(book9)

        val book10 = Book(
            R.drawable.img5,
            "Andy",
            "Hambre torcida",
            "Este retrato muestra el hambre de la gente a la que no podemos inseminar nuestra confianza."
        )
        bookList.add(book10)

    }

    private fun setupBottomNavigationBar() {
        binding.bottomNav.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.menu_configuracion -> {
                    // Iniciar la actividad de configuración
                    startActivity(Intent(this, ConfigActivity::class.java))
                    true
                }
                R.id.menu_informacion -> {
                    // Iniciar la actividad de información
                    startActivity(Intent(this, InfoActivity::class.java))
                    true
                }
                else -> false
            }
        }
    }
}
