package com.example.creepgallery

interface BookClickListener {
    fun onClick(book: Book)
}