package com.example.creepgallery

import androidx.recyclerview.widget.RecyclerView
import com.example.creepgallery.databinding.CardCellBinding

class CardViewHolder(
    private val binding: CardCellBinding,
    private val clickListener: BookClickListener
) : RecyclerView.ViewHolder(binding.root) {

    fun bindBook(book: Book) {
        binding.apply {
            Cover.setImageResource(book.cover)
            title.text = book.title
            author.text = book.author
            cardView.setOnClickListener { clickListener.onClick(book) }
        }
    }
}
