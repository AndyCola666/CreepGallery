package com.example.creepgallery

import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class ConfigActivity : AppCompatActivity() {

    private val images = arrayOf(
        R.drawable.fondo,
        R.drawable.fondodos,
        R.drawable.fondotres,
        R.drawable.ex1,
        R.drawable.ex2,
        R.drawable.ex3,
        R.drawable.ex4,
        R.drawable.ex5,
        R.drawable.ex6,
        R.drawable.ex7,
        R.drawable.ex8,
        R.drawable.ex9,
        R.drawable.ex10,


    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_config)

        val gridView: GridView = findViewById(R.id.gridView)
        gridView.adapter = object : BaseAdapter() {
            override fun getCount(): Int {
                return images.size
            }

            override fun getItem(position: Int): Any {
                return images[position]
            }

            override fun getItemId(position: Int): Long {
                return position.toLong()
            }

            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val imageView: ImageView

                if (convertView == null) {
                    // Si la vista no existe, crea una nueva ImageView
                    imageView = ImageView(this@ConfigActivity) // Cambio aquí
                    imageView.layoutParams = ViewGroup.LayoutParams(500, 500) // Cambio aquí
                    imageView.scaleType = ImageView.ScaleType.CENTER_CROP // Escala la imagen para que se ajuste al ImageView
                    imageView.setPadding(8, 8, 8, 8) // Añade un relleno para las imágenes
                } else {
                    imageView = convertView as ImageView
                }

                // Establece la imagen en ImageView basado en su posición en el array de imágenes
                imageView.setImageResource(images[position])
                return imageView
            }
        }
    }
}
